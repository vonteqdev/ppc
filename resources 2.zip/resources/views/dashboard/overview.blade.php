<x-app-layout>
   <div class="container">

       <!-- CAROUSEL OVERVIEW -->
       <div class="row">
           @include('dashboard.partials.carousel')
       </div>

       <!-- PRODUCT PERFORMANCE -->
       <div class="row mt-4">
           <h3>Product Performance</h3>
           @include('dashboard.partials.product-performance')
       </div>

       <!-- GOOGLE ADS CAMPAIGNS -->
       <div class="row mt-4">
           <h3>Google Ads Campaigns</h3>
           @include('dashboard.partials.google-ads')
       </div>

       <!-- GOOGLE SHOPPING CAMPAIGNS -->
       <div class="row mt-4">
           <h3>Google Shopping Campaigns</h3>
           @include('dashboard.partials.shopping-campaigns')
       </div>

       <!-- ROAS ANALYSIS -->
       <div class="row mt-4">
           <h3>ROAS Performance</h3>
           @include('dashboard.partials.roas-labels')
       </div>

       <!-- PROFIT PERFORMANCE -->
       <div class="row mt-4">
           <h3>Profit Analysis</h3>
           @include('dashboard.partials.profit-performance')
       </div>

       <!-- PRICE RANGE & REVENUE -->
       <div class="row mt-4">
           <h3>Price Ranges & Revenue</h3>
           @include('dashboard.partials.revenue')
       </div>

       <!-- CLICK PERFORMANCE -->
       <div class="row mt-4">
           <h3>Clicks Performance</h3>
           @include('dashboard.partials.clicks-performance')
       </div>

       <!-- CATEGORY PERFORMANCE -->
       <div class="row mt-4">
           <h3>Category Performance</h3>
           @include('dashboard.partials.categories')
       </div>

       <!-- BRAND PERFORMANCE -->
       <div class="row mt-4">
           <h3>Brand Performance</h3>
           @include('dashboard.partials.brands')
       </div>

   </div>

</x-app-layout>
