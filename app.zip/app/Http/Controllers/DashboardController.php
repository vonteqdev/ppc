<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\ProductLabelingService;
use App\Models\Product;
use App\Models\GoogleAdsCampaign;
use App\Models\RevenueReport;
use App\Models\ProductPerformance;
use App\Models\CategoryPerformance;
use App\Models\BrandPerformance;
use App\Models\GoogleShoppingCampaign;
use App\Models\ClickPerformance;

class DashboardController extends Controller
{
    protected $labelingService;

    public function __construct(ProductLabelingService $labelingService)
    {
        $this->labelingService = $labelingService;
    }

    public function index()
    {
        // Assign Product Labels
        $labeledProducts = $this->labelingService->assignLabels();

        // Existing Performance Data
        $productPerformance = ProductPerformance::getOverviewStats();

        // Google Ads Campaign Performance
        $googleAdsData = GoogleAdsCampaign::getPerformance();

        // Google Shopping Campaigns
        $shoppingCampaigns = GoogleShoppingCampaign::getPerformance();

        // Revenue Breakdown
        $revenueData = RevenueReport::getPriceRangeStats();

        // Top Performing Categories & Brands
        $categoryPerformance = CategoryPerformance::getTopCategories();
        $brandPerformance = BrandPerformance::getTopBrands();

        // Click Performance Data
        $clickPerformance = ClickPerformance::getProductClickStats();

        return view('dashboard.overview', compact(
            'labeledProducts',
            'productPerformance',
            'googleAdsData',
            'shoppingCampaigns',
            'revenueData',
            'categoryPerformance',
            'brandPerformance',
            'clickPerformance'
        ));
    }
}
