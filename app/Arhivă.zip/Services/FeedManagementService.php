<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FeedImport;
use App\Models\FeedExport;
use Illuminate\Support\Facades\Storage;

class FeedManagementController extends Controller
{
    /**
     * Display the feed management dashboard.
     */
    public function index()
    {
        $importedFeeds = FeedImport::all();
        $exportedFeeds = FeedExport::all();

        return view('feed-management.index', [
            'feeds' => [
                'imports' => $importedFeeds,
                'exports' => $exportedFeeds
            ]
        ]);
    }

    /**
     * Handle file upload for importing a feed.
     */
    public function importFeed(Request $request)
    {
        $request->validate([
            'feed_name' => 'required|string|max:255',
            'feed_source' => 'required_without:feed_file|url',
            'feed_file' => 'required_without:feed_source|file|mimes:xml,csv',
            'frequency' => 'required|in:hourly,daily,weekly',
        ]);

        if ($request->hasFile('feed_file')) {
            // Store uploaded file
            $file = $request->file('feed_file');
            $path = $file->store('imports', 'public');
            $source = $path;
            $type = $file->extension();
        } else {
            // Store URL source
            $source = $request->feed_source;
            $type = pathinfo($source, PATHINFO_EXTENSION);
        }

        // Validate & Parse Feed
        $isValid = $this->validateFeed($source, $type);
        if (!$isValid) {
            return redirect()->back()->with('error', 'Invalid Feed Format!');
        }

        FeedImport::create([
            'name' => $request->feed_name,
            'source' => $source,
            'type' => $type,
            'frequency' => $request->frequency,
            'last_fetched_at' => now(),
        ]);

        return redirect()->route('feed-management.index')->with('success', 'Feed Imported Successfully.');
    }


    /**
     * Validate Feed Format
     */
    private function validateFeed($source, $type)
    {
        try {
            if ($type == 'xml') {
                $xmlContent = file_get_contents($source);
                new SimpleXMLElement($xmlContent);
            } elseif ($type == 'csv') {
                $csvData = file_get_contents($source);
                if (!str_contains($csvData, ',')) {
                    return false;
                }
            }
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Fetch and update feeds based on schedule.
     */
    public function fetchFeeds()
    {
        $feeds = FeedImport::where('frequency', '!=', '')->get();
        foreach ($feeds as $feed) {
            // Simulating fetching logic, actual implementation may use Curl or Guzzle
            $feed->last_fetched_at = now();
            $feed->save();
        }

        return redirect()->route('feed-management.index')->with('success', 'Feeds updated.');
    }

    /**
     * Create a new export feed.
     */
    public function createExport(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'platform' => 'required|in:google,facebook,tiktok',
            'columns' => 'required|array',
            'filters' => 'nullable|array',
        ]);

        $exportUrl = url('/export/' . strtolower($request->platform) . '-' . str_slug($request->name) . '.xml');

        FeedExport::create([
            'name' => $request->name,
            'platform' => $request->platform,
            'export_url' => $exportUrl,
            'columns' => json_encode($request->columns),
            'filters' => json_encode($request->filters),
        ]);

        return redirect()->route('feed-management.index')->with('success', 'Export Feed Created Successfully.');
    }

    /**
     * Generate export feed content.
     */
    public function generateExport($platform, $name)
    {
        $feed = FeedExport::where('platform', $platform)->where('name', $name)->firstOrFail();
        $products = $this->applyFilters($feed);

        $xml = view('feed-management.export-template', compact('products'))->render();

        return response($xml)->header('Content-Type', 'application/xml');
    }

    /**
     * Apply filters and return the processed feed.
     */
    private function applyFilters($feed)
    {
        // Simulate fetching products from database
        $products = [
            ['id' => 1, 'title' => 'Product 1', 'price' => 19.99, 'availability' => 'in_stock'],
            ['id' => 2, 'title' => 'Product 2', 'price' => 29.99, 'availability' => 'out_of_stock'],
            ['id' => 3, 'title' => 'Product 3', 'price' => 9.99, 'availability' => 'in_stock'],
        ];

        // Apply filters
        if ($feed->filters) {
            $filters = json_decode($feed->filters, true);
            foreach ($filters as $filter) {
                $products = array_filter($products, function ($product) use ($filter) {
                    return eval("return {$product[$filter['field']]} {$filter['operator']} {$filter['value']};");
                });
            }
        }

        return $products;
    }
}
