<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FeedImport;
use App\Models\FeedExport;
use Illuminate\Support\Facades\Storage;

class FeedManagementController extends Controller
{
    // Show Feed Management Dashboard
    public function index()
    {
        $importFeeds = FeedImport::all();
        $exportFeeds = FeedExport::all();
        return view('feed-management.index', compact('importFeeds', 'exportFeeds'));
    }

    // Store Import Feed
    public function storeImport(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'source' => 'required|url',
            'type' => 'required|in:xml,csv,json',
            'frequency' => 'required|in:hourly,daily,weekly',
        ]);

        FeedImport::create($request->all());
        return redirect()->back()->with('success', 'Import Feed Added Successfully');
    }

    // Fetch and Process Feed
    public function fetchFeed($id)
    {
        $feed = FeedImport::findOrFail($id);
        // Logic to fetch and process feed based on type (XML, JSON, CSV)
        $feed->update(['last_fetched_at' => now()]);
        return redirect()->back()->with('success', 'Feed Fetched Successfully');
    }

    // Store Export Feed
    public function storeExport(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'platform' => 'required|string',
            'columns' => 'nullable|array',
            'filters' => 'nullable|array'
        ]);

        $exportUrl = url('/feeds/' . str_slug($request->name));

        FeedExport::create([
            'name' => $request->name,
            'platform' => $request->platform,
            'export_url' => $exportUrl,
            'columns' => $request->columns,
            'filters' => $request->filters
        ]);

        return redirect()->back()->with('success', 'Export Feed Created Successfully');
    }

    // Generate Export Feed URL
    public function viewExport($id)
    {
        $feed = FeedExport::findOrFail($id);
        return response()->json([
            'feed_url' => $feed->export_url,
            'columns' => $feed->columns,
            'filters' => $feed->filters
        ]);
    }
}

